fx_version 'cerulean'
game 'gta5'

author 'tweenzey'
description 'Car Bomb Script for QBcore'
version '1.0.0'
lua54 'yes'


escrow_ignore {
    'config.lua'
}

shared_scripts {
    'config.lua' 
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependency '/assetpacks'