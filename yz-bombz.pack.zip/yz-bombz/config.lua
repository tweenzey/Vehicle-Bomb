Config = {}

-- Required Items
Config.BombItem = "car_bomb" -- Item required to place the bomb
Config.DefuserItem = "bomb_defuser" -- Item required to defuse the bomb

-- Notifications
Config.Notifications = {
    PlacingBomb = "Placing the bomb... do not be interrupted!", -- Notification when starting to place a bomb
    BombPlaced = "Bomb successfully placed!", -- Notification when the bomb is placed
    BombPlacementCancelled = "Bomb placement canceled!", -- Notification when bomb placement is cancelled
    NoVehicleNearby = "No vehicle nearby!", -- Notification when no vehicle is found
    MustBeCloser = "You must be at the front of the vehicle!", -- Notification when too far from the vehicle
    NoBombItem = "You do not have the required items to place the bomb!", -- Notification when the player doesn't have the bomb item
    DefusingBomb = "Defusing the bomb... stay focused", -- Notification when starting to defuse a bomb
    BombDefused = "Bomb successfully defused!", -- Notification when the bomb is defused
    BombDefusalCancelled = "Bomb defusal canceled", -- Notification when bomb defusal is cancelled
    NoDefuserItem = "You do not have the defuser kit!", -- Notification when the player doesn't have the defuser item
    BombExplodedDuringPlacement = "The bomb exploded while being placed!", -- Notification when the bomb explodes while placing
    BombExplodedDuringDefusal = "The bomb exploded during defusal!", -- Notification when the bomb explodes while defusing
    VehicleWillExplode = "The vehicle will explode soon!", -- Notification before the vehicle explodes
    VehicleExploded = "The vehicle has exploded!" -- Notification when the vehicle explodes
}

-- Durations (in milliseconds)
Config.PlacingDuration = 15000 -- Duration for placing a bomb (15 seconds)
Config.DefusingDuration = 15000 -- Duration for defusing a bomb (15 seconds)

-- Explosion Chances (percent)
Config.BombExplosionChance = 15 -- % chance the bomb will explode during placement
Config.DefuseExplosionChance = 10 -- % chance the bomb will explode during defusal
