🚗💣 Car Bomb Script for QBCore 💣🚗
A comprehensive and immersive script for the QBCore framework that allows players to place and defuse bombs on vehicles. Enhance your FiveM server's gameplay by introducing high-stakes mechanics where players can strategically use explosives to impact other players' vehicles.

📜 Table of Contents
✨ Features
🔧 Requirements
📥 Installation
⚙️ Configuration
🎮 Usage
🛠️ Commands
🔔 Notifications
🎨 Customization
🤝 Contributing
📄 License
✨ Features
🚗 Place Bombs on Vehicles: Attach bombs to nearby vehicles, adding an element of strategy and risk.
🛡️ Defuse Bombs: Equipped players can defuse bombs before they detonate, requiring teamwork and coordination.
💥 Random Explosion Chance: Configurable chances for bombs to explode during placement or defusal, increasing unpredictability.
⏳ Progress Bars & Animations: Visual and interactive feedback during bomb placement and defusal.
🔔 Notifications: Informative alerts keep players updated on bomb statuses and actions.
🔍 Vehicle Monitoring: Automatically checks vehicles with bombs when players enter them, triggering explosions if necessary.
📝 Logging: Logs kills caused by bomb explosions for administrative oversight.
🔧 Requirements
🕹️ FiveM: A multiplayer modification framework for GTA V.
🔗 QBCore Framework: The script is built specifically for the QBCore framework.
📦 Dependencies:
qb-core: Core functions and utilities.
qb-progressbar: For displaying progress bars during actions.
qb-notify: For in-game notifications.
📥 Installation
🔽 Download the Script:

Clone or download the repository to your local machine.
bash
Code kopieren
git clone https://github.com/your-repo/carbomb.git
📂 Add to Server:

Place the carbomb folder inside your server's resources directory.
markdown
Code kopieren
your-server/
└── resources/
    └── carbomb/
📝 Update server.cfg:

Add the following line to your server.cfg to ensure the resource starts with the server:
cfg
Code kopieren
ensure carbomb
📦 Install Dependencies:

Ensure all required dependencies (qb-core, qb-progressbar, qb-notify) are installed and started before the carbomb resource.
cfg
Code kopieren
ensure qb-core
ensure qb-progressbar
ensure qb-notify
ensure carbomb
⚙️ Configuration
Customize the script via the config.lua file. Below are the configurable options:

lua
Code kopieren
Config = {}

-- 🛠️ Required Items
Config.BombItem = "car_bomb" -- Item required to place the bomb
Config.DefuserItem = "bomb_defuser" -- Item required to defuse the bomb

-- 🔔 Notifications
Config.Notifications = {
    PlacingBomb = "🚧 Placing the bomb... do not be interrupted!", -- When starting to place a bomb
    BombPlaced = "💣 Bomb successfully placed!", -- When the bomb is placed
    BombPlacementCancelled = "❌ Bomb placement canceled!", -- When bomb placement is cancelled
    NoVehicleNearby = "🚫 No vehicle nearby!", -- When no vehicle is found
    MustBeCloser = "🔍 You must be at the front of the vehicle!", -- When too far from the vehicle
    NoBombItem = "🔑 You do not have the required items to place the bomb!", -- When lacking the bomb item
    DefusingBomb = "🛠️ Defusing the bomb... stay focused", -- When starting to defuse a bomb
    BombDefused = "✅ Bomb successfully defused!", -- When the bomb is defused
    BombDefusalCancelled = "❌ Bomb defusal canceled!", -- When bomb defusal is cancelled
    NoDefuserItem = "🔑 You do not have the defuser kit!", -- When lacking the defuser item
    BombExplodedDuringPlacement = "💥 The bomb exploded while being placed!", -- When the bomb explodes during placement
    BombExplodedDuringDefusal = "💥 The bomb exploded during defusal!", -- When the bomb explodes during defusal
    VehicleWillExplode = "⚠️ The vehicle will explode soon!", -- Before the vehicle explodes
    VehicleExploded = "💥 The vehicle has exploded!" -- When the vehicle explodes
}

-- ⏲️ Durations (in milliseconds)
Config.PlacingDuration = 15000 -- Duration for placing a bomb (15 seconds)
Config.DefusingDuration = 15000 -- Duration for defusing a bomb (15 seconds)

-- 🎲 Explosion Chances (percent)
Config.BombExplosionChance = 15 -- 15% chance the bomb will explode during placement
Config.DefuseExplosionChance = 10 -- 10% chance the bomb will explode during defusal
Steps to Configure
✏️ Edit config.lua:

Navigate to the config.lua file in the carbomb resource folder.
Modify the Config table according to your server's requirements.
🎨 Customize Notifications:

Change the text of notifications to better fit your server's theme or language.
🕒 Adjust Durations and Chances:

Modify Config.PlacingDuration and Config.DefusingDuration to change how long actions take.
Adjust Config.BombExplosionChance and Config.DefuseExplosionChance to set the likelihood of bomb explosions.
🎮 Usage
Once installed and configured, players can interact with the car bomb system using specific commands. Ensure that players have the required items (car_bomb and bomb_defuser) in their inventories to perform actions.

🛠️ Commands
🚀 Place a Bomb

Command: /pbomb
Description: Attaches a bomb to the nearest vehicle within a 3.0-meter radius. The player must be within range and have the car_bomb item.
Usage:
🔍 Stand near the target vehicle.
💬 Open the in-game console or chat and type /pbomb.
⏳ Follow on-screen prompts and animations to place the bomb.
🛡️ Defuse a Bomb

Command: /dbomb
Description: Attempts to defuse a bomb attached to the nearest vehicle within a 3.0-meter radius. The player must have the bomb_defuser item.
Usage:
🚗 Approach the vehicle with the bomb.
💬 Open the in-game console or chat and type /dbomb.
⏳ Follow on-screen prompts and animations to defuse the bomb.
⚠️ Notes
💥 Random Explosions:

There is a chance that bombs will explode during placement or defusal based on the configured probabilities.
Explosions will damage or destroy the vehicle and notify the player.
🔄 Player Rotation & Animation:

During bomb placement and defusal, the player character will rotate 180 degrees and perform a mechanic animation to simulate the action.
🔔 Notifications
The script utilizes in-game notifications to inform players about various actions and statuses. These notifications can be customized in the config.lua file under the Config.Notifications table.

🛎️ Available Notifications
🚧 PlacingBomb: Indicates the start of bomb placement.
💣 BombPlaced: Confirms that the bomb has been successfully placed.
❌ BombPlacementCancelled: Alerts the player that bomb placement was canceled.
🚫 NoVehicleNearby: Notifies that there are no vehicles in proximity.
🔍 MustBeCloser: Alerts that the player needs to be closer to the vehicle.
🔑 NoBombItem: Informs the player they lack the required bomb item.
🛠️ DefusingBomb: Indicates the start of bomb defusal.
✅ BombDefused: Confirms that the bomb has been successfully defused.
❌ BombDefusalCancelled: Alerts the player that bomb defusal was canceled.
🔑 NoDefuserItem: Informs the player they lack the required defuser kit.
💥 BombExplodedDuringPlacement: Alerts that the bomb exploded while being placed.
💥 BombExplodedDuringDefusal: Alerts that the bomb exploded during defusal.
⚠️ VehicleWillExplode: Notifies that the vehicle will explode soon.
💥 VehicleExploded: Confirms that the vehicle has exploded.
🎨 Customization
Feel free to customize various aspects of the script to better fit your server's theme and gameplay style:

📏 Distances & Ranges: Adjust the range within which players can place or defuse bombs.
🕒 Timers: Change the durations for bomb placement and defusal actions.
🎲 Explosion Probabilities: Tweak the chances of bombs exploding during actions.
🤝 Contributing
Contributions are welcome! If you'd like to improve the script, report bugs, or suggest new features, please follow these steps:

🐛 Fork the Repository: Click the "Fork" button at the top right of this page.
🌱 Create a Branch: Make a new branch for your feature or bugfix.
bash
Code kopieren
git checkout -b feature/YourFeature
💾 Commit Your Changes: Write clear and concise commit messages.
bash
Code kopieren
git commit -m "Add feature: YourFeature"
📤 Push to GitHub: Push your branch to your forked repository.
bash
Code kopieren
git push origin feature/YourFeature
🔀 Open a Pull Request: Navigate to the original repository and open a pull request with a detailed description of your changes.
Please ensure your contributions adhere to the project's coding standards and include appropriate documentation.

📄 License
This project is licensed under the MIT License.
Feel free to use, modify, and distribute this script as per the license terms.

📞 Contact
For any questions, suggestions, or support, feel free to reach out:

Discord: Your Discord
GitHub Issues: Open an Issue
Thank you for using the Car Bomb Script for QBCore! 🎉
Happy Gaming! 🕹️

<p align="center"> <a href="https://github.com/your-repo/carbomb"> <img src="https://img.shields.io/github/stars/your-repo/carbomb?style=social" alt="GitHub Stars"> </a> <a href="https://github.com/your-repo/carbomb/blob/main/LICENSE"> <img src="https://img.shields.io/github/license/your-repo/carbomb" alt="License"> </a> <a href="https://discord.gg/yugozroleplay"> <img src="https://media.discordapp.net/attachments/1314560431020441622/1316929844004655114/3D_MOCKUP.jpg?ex=6764163e&is=6762c4be&hm=1e2bde4d3d3ba7ae04e4d012be87e4288f81e65486ee277d6eea76dae327d43b&=&format=webp&width=1202&height=676" alt="Discord"> </a> </p>